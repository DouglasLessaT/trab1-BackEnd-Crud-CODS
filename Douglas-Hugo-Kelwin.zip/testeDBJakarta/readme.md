DOUGLAS,HUGO E KELWIN

configurar o pom.XML e persistence.XML
depois fazer um sudo apt install maven
atenção nome do banco de dados ControleDeOrdemDeServico
user = "root"
password = "senha"
